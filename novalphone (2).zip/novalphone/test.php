<form action="check.php">
  <input type="checkbox" name="checkbox" id="checkbox">
  <input type="submit" value="Submit">
</form>

